import Link from "next/link";
import { Home, SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <main className="flex min-h-[70vh] items-center justify-center bg-slate-50 px-4 py-16">
      <div className="w-full max-w-lg rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-xl">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-red-50 text-red-500">
          <SearchX size={38} />
        </div>

        <p className="mt-6 text-sm font-black text-emerald-600">
          ERROR 404
        </p>

        <h1 className="mt-2 text-3xl font-black text-slate-900">
          পেজটি পাওয়া যায়নি
        </h1>

        <p className="mt-3 leading-7 text-slate-500">
          আপনি যে পেজ, পণ্য বা ক্যাটাগরিটি খুঁজছেন
          সেটি পাওয়া যায়নি।
        </p>

        <Link
          href="/"
          className="mt-7 inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3.5 font-black text-white hover:bg-emerald-700"
        >
          <Home size={18} />
          হোম পেজে ফিরে যান
        </Link>
      </div>
    </main>
  );
}