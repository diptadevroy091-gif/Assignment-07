import { auth } from "@/lib/auth";
import { getProductBySlug } from "@/lib/api";
import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowDown,
  ArrowUp,
  MapPin,
  Package,
  Tag,
} from "lucide-react";

function bnNumber(value: number | string) {
  return new Intl.NumberFormat("bn-BD").format(Number(value) || 0);
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  /* =========================
     AUTH CHECK
  ========================= */

  const session = await auth.api.getSession({
    headers: await headers(),
  });

  if (!session) {
    redirect("/signin");
  }

  /* =========================
     GET SLUG
  ========================= */

  const { slug } = await params;

  /* =========================
     GET PRODUCT
  ========================= */

  const product = await getProductBySlug(slug);

  if (!product) {
    notFound();
  }

  const change = Number(product.change || 0);
  const changePercent = Number(
    product.changePercent || 0
  );

  const isUp = change > 0;
  const isDown = change < 0;

  const changeText = isUp
    ? `▲ ${bnNumber(Math.abs(changePercent))}%`
    : isDown
      ? `▼ ${bnNumber(Math.abs(changePercent))}%`
      : "— ০%";

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">

        {/* Back */}
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-emerald-50 hover:text-emerald-700"
        >
          <ArrowLeft size={17} />
          হোম পেজে ফিরে যান
        </Link>

        {/* Main Card */}
        <section className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">

          <div className="grid lg:grid-cols-2">

            {/* =====================
                LEFT
            ===================== */}

            <div className="flex min-h-95 items-center justify-center bg-linear-to-br from-emerald-50 via-white to-lime-50 p-10 sm:min-h-120 lg:min-h-150">
              <div className="text-center">

                <div className="mx-auto flex h-48 w-48 items-center justify-center rounded-full bg-white text-8xl shadow-xl ring-8 ring-emerald-100 sm:h-60 sm:w-60 sm:text-9xl">
                  {product.emoji}
                </div>

                <p className="mt-6 text-sm font-semibold uppercase tracking-widest text-emerald-600">
                  {product.categoryName || product.category}
                </p>

              </div>
            </div>

            {/* =====================
                RIGHT
            ===================== */}

            <div className="p-6 sm:p-10 lg:p-12">

              {/* Category */}
              <div className="mb-4 flex flex-wrap gap-2">

                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700">
                  <Tag size={13} />
                  {product.categoryName || "পণ্য"}
                </span>

                <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600">
                  <Package size={13} />
                  {product.unit}
                </span>

              </div>

              {/* Title */}
              <h1 className="text-3xl font-black leading-tight text-slate-900 sm:text-4xl lg:text-5xl">
                {product.name}
              </h1>

              {/* Description */}
              <p className="mt-5 max-w-2xl text-base leading-8 text-slate-600">
                {product.description}
              </p>

              {/* Price */}
              <div className="mt-8 rounded-2xl bg-slate-50 p-5 ring-1 ring-slate-200">

                <p className="text-sm font-semibold text-slate-500">
                  আজকের দাম
                </p>

                <div className="mt-2 flex flex-wrap items-end gap-3">

                  <span className="text-4xl font-black text-slate-900">
                    ৳ {bnNumber(product.price)}
                  </span>

                  <span className="mb-1 text-sm font-semibold text-slate-500">
                    / {product.unit}
                  </span>

                  <span
                    className={`mb-1 inline-flex items-center rounded-full px-3 py-1 text-sm font-bold ${
                      isUp
                        ? "bg-emerald-100 text-emerald-700"
                        : isDown
                          ? "bg-red-100 text-red-600"
                          : "bg-slate-200 text-slate-600"
                    }`}
                  >
                    {isUp && <ArrowUp size={15} className="mr-1" />}
                    {isDown && <ArrowDown size={15} className="mr-1" />}
                    {changeText}
                  </span>

                </div>

              </div>

              {/* Min / Max / Average */}
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">

                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">
                    সর্বনিম্ন
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900">
                    ৳ {bnNumber(product.minPrice ?? product.price)}
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">
                    সর্বোচ্চ
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900">
                    ৳ {bnNumber(product.maxPrice ?? product.price)}
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">
                    গড় দাম
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900">
                    ৳{" "}
                    {bnNumber(
                      product.averagePrice ?? product.price
                    )}
                  </p>
                </div>

              </div>

            </div>
          </div>

          {/* =====================
              BAZAR PRICES
          ===================== */}

          <div className="border-t border-slate-200 p-6 sm:p-10">

            <div className="mb-6">
              <div className="flex items-center gap-2">
                <MapPin
                  size={21}
                  className="text-emerald-600"
                />

                <h2 className="text-2xl font-black text-slate-900">
                  বাজারভিত্তিক আজকের দাম
                </h2>
              </div>

              <p className="mt-2 text-sm text-slate-500">
                বিভিন্ন বাজার অনুযায়ী আজকের সম্ভাব্য দাম।
              </p>
            </div>

            {product.bazarPrices &&
            product.bazarPrices.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">

                {product.bazarPrices.map(
                  (market, index) => (
                    <div
                      key={`${market.bazar}-${index}`}
                      className="rounded-2xl border border-slate-200 bg-white p-5 transition hover:border-emerald-300 hover:shadow-md"
                    >
                      <div className="flex items-center justify-between gap-3">

                        <div className="flex min-w-0 items-center gap-3">

                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50">
                            <MapPin
                              size={18}
                              className="text-emerald-600"
                            />
                          </div>

                          <p className="truncate font-bold text-slate-800">
                            {market.bazar}
                          </p>

                        </div>

                        <div className="text-right">
                          <p className="text-lg font-black text-slate-900">
                            ৳ {bnNumber(market.price)}
                          </p>

                          <p className="text-xs text-slate-500">
                            / {market.unit || product.unit}
                          </p>
                        </div>

                      </div>
                    </div>
                  )
                )}

              </div>
            ) : (
              <div className="rounded-2xl bg-slate-50 p-8 text-center">
                <p className="font-semibold text-slate-500">
                  এই পণ্যের বাজারভিত্তিক দাম এখন পাওয়া যাচ্ছে না।
                </p>
              </div>
            )}

          </div>

        </section>
      </div>
    </main>
  );
}